CS3516 Project 3
Dan Duff dfduff
10/8/2018

This project is a network routing algorithm simulator.
Distance tables are sent and updated to adjacent nodes via th Bellman-Ford
Distance Vector Routing. 

To 'make' the program:
Type 'make' or 'make all' into the terminal.

To run the program:
Type './project3' into the terminal.

To clean the program:
Type 'make clean' into the terminal.

The tracelevel prompt represents the level in which the user wishes to print debugging/
simulator info. 
All added messages are visible with tracelevel 1 or above. 